using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonEvent : MonoBehaviour
{
  
        [SerializeField] private IntroLoopAudio IntroLoopAudio;

    void Start()
    {

        StartCoroutine("Hoge");
    }
    private IEnumerator Hoge()
    {
        yield return new WaitForSeconds(0.5f);
        IntroLoopAudio.Play();
    }
    
        public void OnClickPlay()
        {
            IntroLoopAudio.Play();
        }
        public void OnClickPause()
        {
            IntroLoopAudio.Pause();
        }
        public void OnClickStop()
        {
            IntroLoopAudio.Stop();
        }
   
}
