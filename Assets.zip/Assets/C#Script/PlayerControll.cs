using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControll : MonoBehaviour
{
    [SerializeField]
    float SPEED = 1.0f;
    private Rigidbody2D rigidBody;
    public Vector2 inputAxis;
    public Transform obj;
    

    // Start is called before the first frame update
    void Start()
    {
        this.rigidBody = GetComponent<Rigidbody2D>();
        this.rigidBody.constraints = RigidbodyConstraints2D.FreezeRotation;
        


    }

    // Update is called once per frame
    void Update()
    {
        inputAxis.x = Input.GetAxis("Horizontal");
        inputAxis.y = Input.GetAxis("Vertical");
    }
    private void FixedUpdate()
    {
        if (inputAxis == Vector2.zero) return;
        rigidBody.velocity = inputAxis * SPEED;
        
        if(inputAxis.x >= 0.5)
        {
            obj.rotation = Quaternion.AngleAxis(-90, new Vector3(0, 0, 1));
        }
        else if (inputAxis.x <= -0.5)
        {
            obj.rotation = Quaternion.AngleAxis(90, new Vector3(0, 0, 1));
        }
        else if (inputAxis.y >= 0.5)
        {
            obj.rotation = Quaternion.AngleAxis(0, new Vector3(0, 0, 1));
        }
        else if (inputAxis.y <= -0.5)
        {
            obj.rotation = Quaternion.AngleAxis(180, new Vector3(0, 0, 1));
        }
        
    }
    

}
