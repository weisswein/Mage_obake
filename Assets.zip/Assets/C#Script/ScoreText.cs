using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ScoreText : MonoBehaviour
{
   
    public Text text_score;
    // Start is called before the first frame update
    void Start()
    {
        text_score.text ="Time: "+ Score.Instance.score.ToString("f1") + "sec.";
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
