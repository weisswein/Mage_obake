using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhoneTenmetu : MonoBehaviour
{
    public float Tenmetuspeed;
    private float time;
    public SpriteRenderer Srphone;
    private bool colortenmetu = false;
    public AudioSource AMS;
    // Start is called before the first frame update
    void Start()
    {
        time = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (colortenmetu)
        {
            Color color = Srphone.color;
            time += Time.deltaTime * Tenmetuspeed;
            // Mathf.Sin()��-1�`1��Ԃ�
            // color��0�`1�Ŏw�肷��
            if (Mathf.Sin(time) < 0.2)
            {
                color.a = Mathf.Sin(time) * 0.5f + 0.5f - Mathf.Sin(time);
            }
            else
            {
                color.a = Mathf.Sin(time) * 0.5f + 0.5f;
            }
            Srphone.color = color;
        }
    }
    IEnumerator OnTriggerEnter2D(Collider2D collision) 
    {
        if (collision.tag == "Wall") { 
            colortenmetu = true;
            AMS.Play();
            yield return new WaitForSeconds(2.0f);
            colortenmetu = false;
        }

    }
}
