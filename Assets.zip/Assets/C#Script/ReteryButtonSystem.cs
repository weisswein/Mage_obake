using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ReteryButtonSystem : MonoBehaviour
{
    [SerializeField] private float loadtime = 1.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public void RetryButtonClick()
    {
        FadeManager.Instance.LoadScene("StartScene", loadtime);
    }
    
}
