using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ghost : MonoBehaviour
{



    [Header("�ړ����x")] public float speed;//�H��̑���
    [Header("�ŏ��̌���")] public int xVector, yVector;//�H�삪��������

    private float time = 0f;
    public int obakenumber = 4;
    /// <summary>
    /// PhoneCall�̃C���^�[�o���p�^�C�}�[
    /// </summary>
    const float interval = 1.0f; // �w��b
    float timer = 0f;
    bool timeron = false;
    const float interval2 = 0.5f; // �w��b
    float timer2 = 0f;
    bool timeron2 = false;

    const float interval3 = 0.1f; // �w��b
    float timer3 = 0f;
    bool timeron3 = false;

    private bool deadobake = true;//�|�����������������Ȃ��Ȃ锻��p
    private Rigidbody2D rb = null;
    private SpriteRenderer sr = null;


    public Sprite ChangeSprite;
    public Sprite ChangeSprite2;
    public AudioClip findout;
    private AudioSource AMphone;
    private AudioSource DeadVoice;

    /// <summary>
    /// ���������ōs�������Ȃ����߂̔���Xco�AYco
    /// </summary>
    public bool Xco = false;
    public bool Yco = false;
    /// <summary>
    /// �e�ǂ̓����蔻��@trigger
    /// </summary>
    private bool Hitd = false;
    private bool Hitt = false;

    private bool onetimehit = true;






    // Start is called before the first frame update
    void Start()
    {
        DeadVoice = this.GetComponent<AudioSource>();
        rb = this.GetComponent<Rigidbody2D>();
        sr = this.GetComponent<SpriteRenderer>();
       // sr.maskInteraction = SpriteMaskInteraction.None;
        rb.velocity = new Vector2(xVector * speed, yVector * speed); //�S�[�X�g�ɓ�����^����

    }

    void Update()
    {

        time += Time.deltaTime;
        if (timeron)

        {

            timer += Time.deltaTime;

            if (timer >= interval)

            {

                timeron = false;

                timer = 0;

            }

        }
        if (timeron2)

        {

            timer2 += Time.deltaTime;

            if (timer2 >= interval2)

            {

                timeron2 = false;

                timer2 = 0;

            }

        }
        if (timeron3)

        {

            timer3 += Time.deltaTime;

            if (timer3 >= interval3)

            {

                timeron3 = false;

                timer3 = 0;

            }

        }

        if (Hitd)
        {
            rb.velocity = Vector3.zero;//�H���x��~


        }
        if (timeron3 == false)
        {
            if (Hitt)
            {
                transform.position += new Vector3(0, 0.1f, 0);
                //sr.color -= new Color(0f/255f, 0f/255f, 0f/255f, 255f/255f);
                GetComponent<Renderer>().material.color -= new Color32(0, 0, 0, 8);
                Debug.Log("����" + transform.position.y + "color:" + sr.color);
                timeron3 = true;
            }
        }

    }
    IEnumerator OnTriggerEnter2D(Collider2D collision)
    {
        if (deadobake)
        {
            if (collision.tag == "Player")
            {

                deadobake = false;
                if (onetimehit)
                {
                    // ���̂��g���K�[�ɐڐG���Ƃ��A�P�x�����Ă΂��
                    sr.color = new Color(255, 255, 255, 255);
                    GetComponent<Renderer>().sortingOrder = 1001;
                    onetimehit = false;
                }
                rb.velocity = Vector3.zero;//�H���x��~
                Hitd = true;
                sr.maskInteraction = SpriteMaskInteraction.None;//SpriteRenderer�̃}�X�N���O��
                yield return new WaitForSeconds(0.5f);
                Hitt = true;
                sr.sprite = ChangeSprite;//�H��̉摜��؂�ւ���
                DeadVoice.clip = findout;
                DeadVoice.Play();
                yield return new WaitForSeconds(3.0f);

                sr.sprite = ChangeSprite2;//�H��̉摜��؂�ւ���
                Hitt = false;
                GetComponent<Renderer>().material.color = new Color32(255, 255, 255, 255);
                Destroy(this.gameObject, 2.0f);

            }

            if (collision.tag == "Ground")
            {
                if (!timeron2)
                {

                    int rnd = Random.Range(1, 3);

                    if (yVector != 0)
                    {
                        Xco = true;
                        Yco = false;
                    }
                    else if (xVector != 0)
                    {
                        Yco = true;
                        Xco = false;
                    }
                    //rb.velocity = new Vector2(0, 0);//�H���x��~
                    xVector = 0;
                    yVector = 0;
                    if (Xco)
                    {
                        if (rnd == 1)
                        {
                            xVector = -1;//�S�[�X�g�̂����W�̈ړ��l

                        }
                        else
                        {
                            xVector = 1;

                        }
                    }

                    else if (Yco)
                    {
                        if (rnd == 2)
                        {
                            yVector = -1;//�S�[�X�g�̂����W�̈ړ��l

                        }
                        else
                        {
                            yVector = 1;

                        }
                    }

                    yield return new WaitForSeconds(0.5f);
                    rb.velocity = new Vector2(xVector * speed, yVector * speed); //�S�[�X�g�ɓ�����^����
                    timeron2 = true;
                }
            }
            ///
            /// �d�b�̓����蔻��ɓ���������
            /// ����炷�B
            ///
            /*if (timeron == false)
            {
                if (collision.tag == "PhoneLeft")
                {
                    AMphone = collision.gameObject.GetComponentInParent<AudioSource>();
                    AMphone.Play(); Debug.Log("Play");
                   
                  
                    timeron = true;

                }
                else if (collision.tag == "PhoneRight")
                {
                    AMphone = collision.gameObject.GetComponentInParent<AudioSource>();
                    AMphone.Play();
                    Debug.Log("Play");
                    }
                    timeron = true;
                }
                else if (collision.tag == "PhoneML")
                {
                    AMphone = collision.gameObject.GetComponentInParent<AudioSource>();
                    AMphone.Play();
                    Debug.Log("Play");
    }
                    timeron = true;
                }
                else if (collision.tag == "PhoneMR")
                {
                    AMphone = collision.gameObject.GetComponentInParent<AudioSource>();
                    AMphone.Play();
                    Debug.Log("Play");

                    timeron = true;
                }

            
            }*/
        }
    }
}

    
   



