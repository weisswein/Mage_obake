using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyManager : MonoBehaviour
{
    [SerializeField] float loadtime2;
    private GameObject[] enemyBox;
    public bool TimerJudgement = false;
    public bool LScene = false;
    int rmd = 0;
    void Start()
    {
        
        rmd = Random.Range(0, 7);
        if (rmd == 0)
        {
            for (int i = 0; i < 3; i++)
                transform.GetChild(i).gameObject.SetActive(false);
        }
        else if (rmd == 1)
        {
            for (int i = 1; i < 4; i++)
                transform.GetChild(i).gameObject.SetActive(false);
        }
        else if (rmd == 2)
        {
            for (int i = 2; i < 5; i++)
                transform.GetChild(i).gameObject.SetActive(false);
        }
        else if (rmd == 3)
        {
            for (int i = 3; i < 6; i++)
                transform.GetChild(i).gameObject.SetActive(false);
        }
        else if (rmd == 4)
        {
            for (int i = 4; i < 7; i++)
            {
                transform.GetChild(i).gameObject.SetActive(false);
            }
        }
        else if (rmd == 5)
        {
            for (int i = 5; i < 8; i++)
            {
                if (i >= 7)
                {
                    transform.GetChild(i - 7).gameObject.SetActive(false);
                }
                else { transform.GetChild(i).gameObject.SetActive(false); }
            }
        }
        else if (rmd == 6)
        {
            for (int i = 6; i < 9; i++)
            {
                if (i >= 7) {
                    transform.GetChild(i - 7).gameObject.SetActive(false); 
                }else { transform.GetChild(i).gameObject.SetActive(false); }
            }
        }



    }
    void Update()
    {
        enemyBox = GameObject.FindGameObjectsWithTag("Wall");

        print("�G�̐��F" + enemyBox.Length);
        if(!LScene)
        if ((enemyBox.Length) == 1)
        {
            TimerJudgement = true;
            FadeManager.Instance.LoadScene("GameClear", loadtime2);
                LScene = true;
        }
    }
}