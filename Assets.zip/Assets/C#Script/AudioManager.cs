using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public AudioClip soundL, soundR, soundMR, soundML;
    private AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {
        audioSource = this.GetComponent<AudioSource>();
    }

    // Update is called once per frame
    public void SoundLeft()
    {
        audioSource.clip = soundL;
        audioSource.Play();
    }
    public void SoundMLeft()
    {
        audioSource.clip = soundML;
        audioSource.Play();
    }
    public void SoundRight()
    {
        audioSource.clip = soundR;
        audioSource.Play();
    }
    public void SoundMRight()
    {
        audioSource.clip = soundMR;
        audioSource.Play();
    }
}
