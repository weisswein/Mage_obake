using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionRight: MonoBehaviour
{
    /// <summary>
    /// ������ɓG���ǂ�����
    /// </summary>
    //[HideInInspector] public bool isOndown= false;
    public Ghost gh;
    public Rigidbody2D rb;
    IEnumerator OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Wall")
        {
            //isOndown = true;
            gh.xVector = 0; gh.yVector = 0;
            yield return new WaitForSeconds(0.5f);
            gh.xVector = -1; gh.yVector = 0;
            rb.velocity = new Vector2(gh.xVector * gh.speed, gh.yVector * gh.speed);
            yield return null;
        }
    }
    /*
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Wall")
            isOnright = false;
    }*/
}
