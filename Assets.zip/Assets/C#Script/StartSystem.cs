using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartSystem : MonoBehaviour
{
    [SerializeField] float loadtime;
    private AudioSource astart;
    public AudioClip audioClip1;
    private bool hantei = false;
    // Start is called before the first frame update
    void Start()
    {
        astart = this.GetComponent<AudioSource>();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!hantei)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                astart.clip = audioClip1;
                astart.Play();
                FadeManager.Instance.LoadScene("GameScene1", loadtime);
                hantei = true;
            }
        }
    }
}
