using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score 
{
	public readonly static Score Instance = new Score();

	public float score = 0;
	
}
